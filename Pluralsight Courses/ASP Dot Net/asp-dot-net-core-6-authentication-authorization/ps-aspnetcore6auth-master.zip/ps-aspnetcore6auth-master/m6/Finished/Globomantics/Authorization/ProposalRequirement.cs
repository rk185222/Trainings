﻿using Microsoft.AspNetCore.Authorization;

namespace Globomantics.Authorization
{
    public class ProposalRequirement : IAuthorizationRequirement
    {
    }
}
