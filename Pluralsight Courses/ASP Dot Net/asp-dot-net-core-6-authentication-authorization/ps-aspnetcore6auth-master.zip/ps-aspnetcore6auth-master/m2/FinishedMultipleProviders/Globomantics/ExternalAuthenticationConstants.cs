﻿namespace Globomantics
{
    public static class ExternalAuthenticationDefaults
    {
        public const string AuthenticationScheme = "ExternalIdentity";
    }
}
